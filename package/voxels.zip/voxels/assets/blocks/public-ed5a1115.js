/*!
 * 
 * voxels
 * 
 * @author Tiny Pixel Collective, Kelly Mears
 * @version 0.0.1
 * @link https://tinypixel.io/voxels
 * @license MIT
 * 
 * Copyright (c) 2018 Tiny Pixel Collective, Kelly Mears
 * 
 * This software is released under the MIT license. © 2018 Tiny Pixel Colletive, LLC.
 * 
 * Compiled with the help of https://wpack.io
 * A zero setup Webpack Bundler Script for WordPress
 */
(window.wpackiovoxelsblocksJsonp=window.wpackiovoxelsblocksJsonp||[]).push([[2],[,function(o,s,n){"use strict";n.p=window.__wpackIovoxelsassets},,,function(o,s,n){n(1),o.exports=n(5)},function(o,s,n){"use strict";n.r(s);n(6)},function(o,s,n){}],[[4,0]]]);
//# sourceMappingURL=public-ed5a1115.js.map